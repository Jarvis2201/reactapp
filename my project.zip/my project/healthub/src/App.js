import Navbar from "./components/header/header";
import Home from "./components/home/home";
import Products from "./components/product/product";

import LoginPage from "./components/login/login";
import SignupPage from "./components/signup/signup";
import Aboutus from "./components/aboutus/aboutus";
import ContactUS from "./components/contactus/contactus";
import Footer from "./components/footer/footer";

function App() {
  return (
<Aboutus/>
  );
}

export default App;
